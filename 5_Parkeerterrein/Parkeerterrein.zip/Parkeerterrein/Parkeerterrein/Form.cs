﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parkeerterrein.Class;
using System.Threading;
using System.Diagnostics;

namespace Parkeerterrein
{
    public partial class Form : System.Windows.Forms.Form
    {
        [DllImport("K8055D.dll")]
        public static extern int OpenDevice(int iChannel);
        [DllImport("K8055D.dll")]
        public static extern void CloseDevice();
        [DllImport("K8055D.dll")]
        public static extern void SetDigitalChannel(int iLight);
        [DllImport("K8055D.dll")]
        public static extern void ClearAllDigital();

        BarcodeScanner BarSc = new BarcodeScanner();

        db db = new db();

        [DllImport("user32.dll")] static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);
        [DllImport("user32.dll")] static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);
        [DllImport("user32.dll")] static extern bool MoveWindow(IntPtr Handle, int x, int y, int w, int h, bool repaint);

        public Form()
        {
            InitializeComponent();

            for (int i = 0; i < 4; i++)
            {
                if (OpenDevice(i) == i)
                {
                    OpenDevice(i);
                }
            }

            db.GetBarcodes(lstbBlok);


            Process p = Process.Start("notepad.exe");
            p.WaitForInputIdle();
            SetParent(p.MainWindowHandle, panel1.Handle);
        }

        private void Form_FormClosing(object sender, FormClosingEventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                SetDigitalChannel(2);
            }
            ClearAllDigital();
            CloseDevice();
        }

        private void tbBarCode_TextChanged(object sender, EventArgs e)
        {
            BarSc.CheckBarcode(tbBarCode.Text);
        }

        private void btOpenBarcode_Click(object sender, EventArgs e)
        {
            if (lstbBlok.SelectedItem != null)
            {
                string Barcode = lstbBlok.SelectedItem.ToString();

                db.BlokOpenBarcode(Barcode, "Open");
            }
            else
            {
                MessageBox.Show("Geen barcode geselecteerd");
            }
        }

        private void btBlokBarcode_Click(object sender, EventArgs e)
        {
            if (lstbBlok.SelectedItem != null)
            {
                string Barcode = lstbBlok.SelectedItem.ToString();

                db.BlokOpenBarcode(Barcode, "Blokkeer");
            }
            else
            {
                MessageBox.Show("Geen barcode geselecteerd");
            }
        }


        private void btOpenBoom_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                SetDigitalChannel(1);
                SetDigitalChannel(3);
            }
            Thread.Sleep(7500);
            ClearAllDigital();
        }

        private void btSluitBoom_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                SetDigitalChannel(2);
                SetDigitalChannel(4);
            }
            Thread.Sleep(7500);
            ClearAllDigital();
        }

        private void btBoomOpenHouden_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                SetDigitalChannel(1);
                SetDigitalChannel(2);
            }
        }
    }
}
