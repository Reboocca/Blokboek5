﻿namespace Parkeerterrein
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbBarCode = new System.Windows.Forms.TextBox();
            this.lstbBlok = new System.Windows.Forms.ListBox();
            this.btOpenBarcode = new System.Windows.Forms.Button();
            this.btBlokBarcode = new System.Windows.Forms.Button();
            this.grpBlok = new System.Windows.Forms.GroupBox();
            this.lblBarcode = new System.Windows.Forms.Label();
            this.btOpenBoom = new System.Windows.Forms.Button();
            this.grpBedieningSlagboom = new System.Windows.Forms.GroupBox();
            this.btSluitBoom = new System.Windows.Forms.Button();
            this.btBoomOpenHouden = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grpBlok.SuspendLayout();
            this.grpBedieningSlagboom.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbBarCode
            // 
            this.tbBarCode.Location = new System.Drawing.Point(122, 66);
            this.tbBarCode.Name = "tbBarCode";
            this.tbBarCode.Size = new System.Drawing.Size(495, 20);
            this.tbBarCode.TabIndex = 0;
            this.tbBarCode.TextChanged += new System.EventHandler(this.tbBarCode_TextChanged);
            // 
            // lstbBlok
            // 
            this.lstbBlok.FormattingEnabled = true;
            this.lstbBlok.Location = new System.Drawing.Point(6, 19);
            this.lstbBlok.Name = "lstbBlok";
            this.lstbBlok.Size = new System.Drawing.Size(230, 264);
            this.lstbBlok.TabIndex = 1;
            // 
            // btOpenBarcode
            // 
            this.btOpenBarcode.Location = new System.Drawing.Point(129, 284);
            this.btOpenBarcode.Name = "btOpenBarcode";
            this.btOpenBarcode.Size = new System.Drawing.Size(107, 23);
            this.btOpenBarcode.TabIndex = 2;
            this.btOpenBarcode.Text = "Deblokkeren";
            this.btOpenBarcode.UseVisualStyleBackColor = true;
            this.btOpenBarcode.Click += new System.EventHandler(this.btOpenBarcode_Click);
            // 
            // btBlokBarcode
            // 
            this.btBlokBarcode.Location = new System.Drawing.Point(6, 284);
            this.btBlokBarcode.Name = "btBlokBarcode";
            this.btBlokBarcode.Size = new System.Drawing.Size(107, 23);
            this.btBlokBarcode.TabIndex = 3;
            this.btBlokBarcode.Text = "Blokkeren";
            this.btBlokBarcode.UseVisualStyleBackColor = true;
            this.btBlokBarcode.Click += new System.EventHandler(this.btBlokBarcode_Click);
            // 
            // grpBlok
            // 
            this.grpBlok.Controls.Add(this.lstbBlok);
            this.grpBlok.Controls.Add(this.btBlokBarcode);
            this.grpBlok.Controls.Add(this.btOpenBarcode);
            this.grpBlok.Location = new System.Drawing.Point(623, 3);
            this.grpBlok.Name = "grpBlok";
            this.grpBlok.Size = new System.Drawing.Size(243, 313);
            this.grpBlok.TabIndex = 4;
            this.grpBlok.TabStop = false;
            this.grpBlok.Text = "Blokkeren en deblokkeren";
            // 
            // lblBarcode
            // 
            this.lblBarcode.AutoSize = true;
            this.lblBarcode.Location = new System.Drawing.Point(15, 69);
            this.lblBarcode.Name = "lblBarcode";
            this.lblBarcode.Size = new System.Drawing.Size(101, 13);
            this.lblBarcode.TabIndex = 5;
            this.lblBarcode.Text = "Gescande barcode:";
            // 
            // btOpenBoom
            // 
            this.btOpenBoom.Location = new System.Drawing.Point(6, 19);
            this.btOpenBoom.Name = "btOpenBoom";
            this.btOpenBoom.Size = new System.Drawing.Size(199, 35);
            this.btOpenBoom.TabIndex = 6;
            this.btOpenBoom.Text = "Open";
            this.btOpenBoom.UseVisualStyleBackColor = true;
            this.btOpenBoom.Click += new System.EventHandler(this.btOpenBoom_Click);
            // 
            // grpBedieningSlagboom
            // 
            this.grpBedieningSlagboom.Controls.Add(this.btBoomOpenHouden);
            this.grpBedieningSlagboom.Controls.Add(this.btSluitBoom);
            this.grpBedieningSlagboom.Controls.Add(this.btOpenBoom);
            this.grpBedieningSlagboom.Location = new System.Drawing.Point(12, 3);
            this.grpBedieningSlagboom.Name = "grpBedieningSlagboom";
            this.grpBedieningSlagboom.Size = new System.Drawing.Size(605, 60);
            this.grpBedieningSlagboom.TabIndex = 7;
            this.grpBedieningSlagboom.TabStop = false;
            this.grpBedieningSlagboom.Text = "Bediening slagboom";
            // 
            // btSluitBoom
            // 
            this.btSluitBoom.Location = new System.Drawing.Point(410, 19);
            this.btSluitBoom.Name = "btSluitBoom";
            this.btSluitBoom.Size = new System.Drawing.Size(189, 35);
            this.btSluitBoom.TabIndex = 7;
            this.btSluitBoom.Text = "Sluiten";
            this.btSluitBoom.UseVisualStyleBackColor = true;
            this.btSluitBoom.Click += new System.EventHandler(this.btSluitBoom_Click);
            // 
            // btBoomOpenHouden
            // 
            this.btBoomOpenHouden.Location = new System.Drawing.Point(211, 19);
            this.btBoomOpenHouden.Name = "btBoomOpenHouden";
            this.btBoomOpenHouden.Size = new System.Drawing.Size(193, 35);
            this.btBoomOpenHouden.TabIndex = 8;
            this.btBoomOpenHouden.Text = "Open houden";
            this.btBoomOpenHouden.UseVisualStyleBackColor = true;
            this.btBoomOpenHouden.Click += new System.EventHandler(this.btBoomOpenHouden_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(17, 92);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 218);
            this.panel1.TabIndex = 8;
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 322);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.grpBedieningSlagboom);
            this.Controls.Add(this.lblBarcode);
            this.Controls.Add(this.grpBlok);
            this.Controls.Add(this.tbBarCode);
            this.Name = "Form";
            this.Text = "Stuur";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_FormClosing);
            this.grpBlok.ResumeLayout(false);
            this.grpBedieningSlagboom.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbBarCode;
        private System.Windows.Forms.ListBox lstbBlok;
        private System.Windows.Forms.Button btOpenBarcode;
        private System.Windows.Forms.Button btBlokBarcode;
        private System.Windows.Forms.GroupBox grpBlok;
        private System.Windows.Forms.Label lblBarcode;
        private System.Windows.Forms.Button btOpenBoom;
        private System.Windows.Forms.GroupBox grpBedieningSlagboom;
        private System.Windows.Forms.Button btSluitBoom;
        private System.Windows.Forms.Button btBoomOpenHouden;
        private System.Windows.Forms.Panel panel1;
    }
}

