﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows;
using System.Data;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

namespace Parkeerterrein.Class
{
    class BarcodeScanner
    {
        private string conn;
        private MySqlConnection connect;
        
        [DllImport("K8055D.dll")]
        public static extern int OpenDevice(int iChannel);
        [DllImport("K8055D.dll")]
        public static extern void CloseDevice();
        [DllImport("K8055D.dll")]
        public static extern void SetDigitalChannel(int iLight);
        [DllImport("K8055D.dll")]
        public static extern void ClearAllDigital();

        string OpenBoomTijd;

        db db = new db();

        public BarcodeScanner()
        {
            Database();
        }

        public void Database()
        {
            try
            {
                conn = "Server=localhost;Database=parkeerterrein;Uid=root;Pwd=;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }

            catch (MySqlException)
            {
                throw;
            }
        }

        public void CheckBarcode(string Text)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand();

                cmd.CommandText = "SELECT `BarCode`,`Geblokkeerd` FROM `barcode` WHERE `BarCode` = @barcode and `Geblokkeerd` = '1'";
                cmd.Parameters.AddWithValue("@barcode", Text);
                cmd.Connection = connect;

                object result = cmd.ExecuteScalar();

                if (result != null)
                {
                    connect = new MySqlConnection(conn);
                    connect.Open();

                    ClearAllDigital();
                    SetDigitalChannel(1);
                    SetDigitalChannel(3);
                    Thread.Sleep(7500);
                    SetDigitalChannel(2);
                    SetDigitalChannel(4);
                    ClearAllDigital();


                    OpenBoomTijd = DateTime.Now.ToString();

                    db.BoomOpen(OpenBoomTijd);

                }
                else
                {
                    SetDigitalChannel(4);

                    MessageBox.Show("Uw barcode word niet herkent, raadpleeg de parkeerwachter");
                }
            }
            catch (Exception)
            {
                throw;
            }
            
        }
    }
}
