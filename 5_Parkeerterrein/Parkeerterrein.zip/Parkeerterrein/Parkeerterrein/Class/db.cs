﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace Parkeerterrein.Class
{
    class db
    {
        private string conn;
        private MySqlConnection connect;

        public db()
        {
            Database();
        }

        public void Database()
        {
            try
            {
                conn = "Server=localhost;Database=parkeerterrein;Uid=root;Pwd=;";
                connect = new MySqlConnection(conn);
                connect.Open();
            }

            catch (MySqlException)
            {
                throw;
            }
        }

        public void GetBarcodes(ListBox bx)
        {
            DataTable dtBarc = new DataTable();

            dtBarc.Columns.Add("Barcode");

            MySqlCommand cmd = new MySqlCommand();

            cmd.CommandText = "SELECT `BarCode`FROM `barcode`";
            cmd.Connection = connect;

            bx.Items.Add(cmd.ExecuteScalar());
            
        }

        public void BoomOpen(string OpenBoomTijd)
        {
            try
            {
                MySqlCommand cmd2 = new MySqlCommand();

                cmd2.CommandText = "INSERT INTO `tijd`(`PersoonID`, `TijdIn`) VALUES (@persnr, @TijdIN)";
                cmd2.Parameters.AddWithValue("@persnr", 1);
                cmd2.Parameters.AddWithValue("@TijdIN", OpenBoomTijd);
                cmd2.Connection = connect;


                cmd2.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void BlokOpenBarcode(string barcode, string opensluit)
        {
            if (opensluit == "Open")
            {
                MySqlCommand cmd2 = new MySqlCommand();
                
                cmd2.CommandText = "UPDATE `barcode` SET `Geblokkeerd`= 1 WHERE `BarCode` = @barc";
                cmd2.Parameters.AddWithValue("@barc", barcode);
                cmd2.Connection = connect;


                cmd2.ExecuteNonQuery();

                MessageBox.Show("De barcode: " + barcode + ", is gedeblokkeerd");
            }
            else if (opensluit == "Blokkeer")
            {
                MySqlCommand cmd2 = new MySqlCommand();

                cmd2.CommandText = "UPDATE `barcode` SET `Geblokkeerd`= 2 WHERE `BarCode` = @barc";
                cmd2.Parameters.AddWithValue("@barc", barcode);
                cmd2.Connection = connect;


                cmd2.ExecuteNonQuery();

                MessageBox.Show("De barcode: " + barcode + ", is gedeblokkeerd");
            }
        }
    }
}
