﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for Administratie.xaml
    /// </summary>
    public partial class Administratie : Window
    {
        DB database = new DB();

        private int Rol = 0;
        public Administratie()
        {
            InitializeComponent();
        }

        private void cbRol_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbRol.Text == "Logistiek")
            {
                Rol = 1;
            }

            else if (cbRol.Text == "Magazijn")
            {
                Rol = 2;
            }

            else if (cbRol.Text == "Administratie")
            {
                Rol = 3;
            }
        }

        private void btToevoeg_Click(object sender, RoutedEventArgs e)
        {
            if (tbUsername.Text == "" || tbPassword.Text == "" || cbRol.Text == "")
            {
                MessageBox.Show("Niet alles is ingevuld!");
            }
            else if (database.CheckUsername(tbUsername.Text))
            {
                MessageBox.Show("Deze gebruikersnaam bestaat al in de database.");
            }
            else
            {
                database.InsertAccount(tbUsername.Text, tbPassword.Text, Rol);
                MessageBox.Show("Het account is toegevoegd. De username is " + tbUsername.Text + ", het wachtwoord is " + tbPassword.Text + " en de rol is " + cbRol.Text);
                tbUsername.Text = "";
                tbPassword.Text = "";
                cbRol.Text = "";
            }
        }
    }
}
