﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Xml.Serialization;
using System.IO;
using Xceed.Wpf.DataGrid;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for Logistiek.xaml
    /// </summary>
    public partial class Logistiek : Window
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;Database=voorraadbeheer;UID=root;pwd=;");
        DataTable dtBestel = new DataTable();
        DataTable dtXml = new DataTable();
        DataTable dtDateTomorrow = new DataTable();
        DataTable dtDateToday = new DataTable();
        DataSet dsXml = new DataSet();

        public Logistiek()
        {
            InitializeComponent();
            GetOverzicht();
            GetVoorstel();
        }

        private void GetOverzicht()
        {
            con.Open();
            MySqlCommand GetMed = new MySqlCommand("SELECT id AS nr, Naam AS naam, Voorraad AS aantal FROM medicijnen", con);
            MySqlCommand GetOver = new MySqlCommand("SELECT artnr AS nr, omschrijving AS naam, lopendevoorraad AS aantal FROM overige", con);
            con.Close();

            MySqlDataAdapter adapter1 = new MySqlDataAdapter(GetMed);
            DataTable dt = new DataTable();
            adapter1.Fill(dt);
            MySqlDataAdapter adapter2 = new MySqlDataAdapter(GetOver);
            adapter2.Fill(dt);
            dgVoorraad.ItemsSource = dt.DefaultView;
        }

        private void GetVoorstel()
        {
            con.Open();
            MySqlCommand GetMed = new MySqlCommand("SELECT id AS nr, Naam AS naam, Doelvoorraad - Voorraad AS aantal FROM medicijnen WHERE Voorraad <= Bestelniveau", con);
            MySqlCommand GetOverig = new MySqlCommand("SELECT artnr AS nr, omschrijving AS Naam, `gewenste voorraad` - lopendevoorraad AS aantal FROM overige WHERE lopendevoorraad <= bestelniveau", con);
            con.Close();

            MySqlDataAdapter adapter1 = new MySqlDataAdapter(GetMed);
            adapter1.Fill(dtBestel);
            MySqlDataAdapter adapter2 = new MySqlDataAdapter(GetOverig);
            adapter2.Fill(dtBestel);
            dgvoorstel.ItemsSource = dtBestel.DefaultView;
        }

        private void Refresh(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("De gegevens worden opnieuw geladen");
            GetOverzicht();
            GetVoorstel();
        }

        private void xmlSaveVoorstel(object sender, RoutedEventArgs e)
        {
            var tomorrow = DateTime.Today.AddDays(1).ToShortDateString();
            var today = DateTime.Today.ToShortDateString();
            dtDateToday.Columns.Add("DatumVandaag");
            dtDateToday.Rows.Add(today);
            dtDateToday.TableName = "datumref";
            dtDateTomorrow.Columns.Add("DatumMorgen");
            dtDateTomorrow.Rows.Add(tomorrow);
            dtDateTomorrow.TableName = "leverdatum";
            DateTime.Now.ToShortDateString();
            dtXml = ((DataView)dgvoorstel.ItemsSource).ToTable();
            dtXml.TableName = "artikel";
            dsXml.DataSetName = "bestelling";
            dsXml.Tables.Add(dtDateToday);
            dsXml.Tables.Add(dtDateTomorrow);
            dsXml.Tables.Add(dtXml);
            dsXml.WriteXml(@"D:\school\Leerjaar 2\Blokboek\Vooraadbeheersysteem\Xml files\Order.xml");
            MessageBox.Show("De spullen die moeten worden gekocht zijn opgeslagen in een bestand.");
        }

        /*private void Button_Click(object sender, RoutedEventArgs e)
        {
            var tomorrow = DateTime.Today.AddDays(1).ToShortDateString();
            var today = DateTime.Today.ToShortDateString();
            dtDateToday.Columns.Add("DatumVandaag");
            dtDateToday.Rows.Add(today);
            dtDateToday.TableName = "datumref";
            dtDateTomorrow.Columns.Add("DatumMorgen");
            dtDateTomorrow.Rows.Add(tomorrow);
            dtDateTomorrow.TableName = "leverdatum";
            DateTime.Now.ToShortDateString();
            dtXml = ((DataView)dgOnderhoud.ItemsSource).ToTable();
            dtXml.TableName = "artikel";
            dtDateToday.Merge(dtDateTomorrow);
            dtDateToday.Merge(dtXml);

            dtDateToday.WriteXml(@"D:/school/Leerjaar 2/Blokboek/Vooraadbeheersysteem/Vooraadbeheersysteem/bin/Order.xml");
            MessageBox.Show("De spullen die moeten worden gekocht zijn opgeslagen in een bestand.");
        }*/
    }
}
