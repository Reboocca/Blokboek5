﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using System.Data.SqlClient;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for Logistiek.xaml
    /// </summary>
    public partial class Logistiek : Window
    {
        DB database = new DB();
        MySqlConnection con = new MySqlConnection("Server=localhost;Database=voorraadbeheer;UID=root;pwd=;");
        DataTable dtBestel = new DataTable();

        public Logistiek()
        {
            InitializeComponent();
            GetOverzicht();
            GetVoorstel();
        }

        private void GetOverzicht()
        {
            con.Open();
            MySqlCommand GetMed = new MySqlCommand("SELECT id AS nr, Naam AS naam, Voorraad AS aantal FROM medicijnen", con);
            MySqlCommand GetOver = new MySqlCommand("SELECT artnr AS nr, omschrijving AS naam, lopendevoorraad AS aantal FROM overige", con);
            con.Close();

            MySqlDataAdapter adapter1 = new MySqlDataAdapter(GetMed);
            DataTable dt = new DataTable();
            adapter1.Fill(dt);
            MySqlDataAdapter adapter2 = new MySqlDataAdapter(GetOver);
            adapter2.Fill(dt);
            dgVoorraadMed.ItemsSource = dt.DefaultView;
        }

        private void GetVoorstel()
        {
            con.Open();
            MySqlCommand GetMed = new MySqlCommand("SELECT id AS nr, Naam AS naam, Doelvoorraad - Voorraad AS aantal FROM medicijnen WHERE Voorraad <= Bestelniveau", con);
            MySqlCommand GetOverig = new MySqlCommand("SELECT artnr AS nr, omschrijving AS Naam, `gewenste voorraad` - lopendevoorraad AS aantal FROM overige WHERE lopendevoorraad <= bestelniveau", con);
            con.Close();

            MySqlDataAdapter adapter1 = new MySqlDataAdapter(GetMed);
            adapter1.Fill(dtBestel);
            MySqlDataAdapter adapter2 = new MySqlDataAdapter(GetOverig);
            adapter2.Fill(dtBestel);
            dgvoorstel.ItemsSource = dtBestel.DefaultView;
        }

        private void Refresh(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("De gegevens worden opnieuw geladen");
            GetOverzicht();
            GetVoorstel();
        }

        private void xmlSaveVoorstel(object sender, RoutedEventArgs e)
        {
            DataTable dtXml = new DataTable();
            dtXml = ((DataView)dgvoorstel.ItemsSource).ToTable();
            dtXml.WriteXml(@"D:/school/Leerjaar 2/Blokboek/Vooraadbeheersysteem/Vooraadbeheersysteem/bin/Order.xml");
            MessageBox.Show("De spullen die moeten worden gekocht zijn opgeslagen in een bestand.");
        }
    }
}
