﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DB database = new DB();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btLogin_Click(object sender, RoutedEventArgs e)
        {
            if (database.CheckLogin(tbUsername.Text, tbPassword.Password))
            {
                switch (RolID(tbUsername.Text))
                {
                    case 1:
                        this.Hide();
                        Logistiek logistiek = new Logistiek();
                        logistiek.ShowDialog();
                        this.Close();
                        break;
                    case 2:
                        this.Hide();
                        Magazijn magazijn = new Magazijn();
                        magazijn.ShowDialog();
                        this.Close();
                        break;
                    case 3:
                        this.Hide();
                        Administratie administratie = new Administratie();
                        administratie.ShowDialog();
                        this.Close();
                        break;
                }
            }
            else if (tbUsername.Text != String.Empty && tbPassword.Password != String.Empty)
            {
                tbPassword.Password = String.Empty;
                MessageBox.Show("Naam en/of wachtwoord fout.");
            }
            else
            {
                MessageBox.Show("Naam en/of wachtwoord zijn niet ingevuld.");
            }
        }

        // Zorgen dat RolID goede int krijgt voor de inlogcode
        public int RolID(string username)
        {
            var result = database.CheckRol(username);
            return result.RolID;
        }

        public class LoginData
        {
            public int RolID { get; set; }
        }
    }
}
