﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string LogistiekUsername = "Logistiek";
        public string LogistiekPassword = "Logistiek";

        public string MagazijnUsername = "Magazijn";
        public string MagazijnPassword = "Magazijn";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btLogin_Click(object sender, RoutedEventArgs e)
        {
            if (tbUsername.Text == LogistiekUsername | tbPassword.Text == LogistiekPassword)
            {
                this.Hide();
                Logistiek Logi = new Logistiek();
                Logi.Show();
                this.Close();
            }
            else if (tbUsername.Text == MagazijnUsername | tbPassword.Text == MagazijnPassword)
            {
                this.Hide();
                Magazijn Maga = new Magazijn();
                Maga.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Je gebruikersnaam en/of wachtwoord is fout.");
            }
        }
    }
}
