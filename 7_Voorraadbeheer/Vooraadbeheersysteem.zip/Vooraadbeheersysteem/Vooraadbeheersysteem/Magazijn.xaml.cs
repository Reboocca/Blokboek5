﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for Magazijn.xaml
    /// </summary>
    public partial class Magazijn : Window
    {
        DB database = new DB();
        bool isChar = true;

        public Magazijn()
        {
            InitializeComponent();
        }

        //auto product bij barcode zoeken
        private void tbBarcodeMedicijnen_TextChanged(object sender, TextChangedEventArgs e)
        {
            tbProductUitgifte.Text = "";
            tbProductBinnenkomst.Text = "";
            tbProductRetour.Text = "";

            //uitgifte
            foreach (char c in tbBarcodeUitgifte.Text)
            {
                if (!char.IsNumber(c))
                {
                    isChar = false;
                }
                if (isChar)
                {
                    if (tbBarcodeUitgifte.Text != "")
                    {
                        tbProductUitgifte.Text = database.SearchNameMedicijn(tbBarcodeUitgifte.Text, tbProductUitgifte.Text);
                        tbProductUitgifte.Text = database.SearchNameOverige(tbBarcodeUitgifte.Text, tbProductUitgifte.Text);
                        iudAantalUitgifte.Maximum = database.MaxMedicijn(tbBarcodeUitgifte.Text, Convert.ToInt32(iudAantalUitgifte.Maximum));
                        iudAantalUitgifte.Maximum = database.MaxOverige(tbBarcodeUitgifte.Text, Convert.ToInt32(iudAantalUitgifte.Maximum));
                    }
                }
                else
                {
                    tbBarcodeUitgifte.Text = "";
                    tbProductUitgifte.Text = "";
                    iudAantalUitgifte.Text = "0";
                    MessageBox.Show("Voer a.u.b. alleen cijfers in.");
                    isChar = true;
                }
            }

            //binnenkomst
            foreach (char c in tbBarcodeBinnenkomst.Text)
            {
                if (!char.IsNumber(c))
                {
                    isChar = false;
                }
                if (isChar)
                {
                    if (tbBarcodeBinnenkomst.Text != "")
                    {
                        tbProductBinnenkomst.Text = database.SearchNameMedicijn(tbBarcodeBinnenkomst.Text, tbProductBinnenkomst.Text);
                        tbProductBinnenkomst.Text = database.SearchNameOverige(tbBarcodeBinnenkomst.Text, tbProductBinnenkomst.Text);
                    }
                }
                else
                {
                    tbBarcodeBinnenkomst.Text = "";
                    tbProductBinnenkomst.Text = "";
                    iudAantalBinnenkomst.Text = "0";
                    MessageBox.Show("Voer a.u.b. alleen cijfers in.");
                    isChar = true;
                }
            }

            //retour
            foreach (char c in tbBarcodeRetour.Text)
            {
                if (!char.IsNumber(c))
                {
                    isChar = false;
                }
                if (isChar)
                {
                    if (tbBarcodeRetour.Text != "")
                    {
                        tbProductRetour.Text = database.SearchNameMedicijn(tbBarcodeRetour.Text, tbProductRetour.Text);
                        tbProductRetour.Text = database.SearchNameOverige(tbBarcodeRetour.Text, tbProductRetour.Text);
                    }
                }
                else
                {
                    tbBarcodeRetour.Text = "";
                    tbProductRetour.Text = "";
                    iudAantalRetour.Text = "0";
                    MessageBox.Show("Voer a.u.b. alleen cijfers in.");
                    isChar = true;
                }
            }
        }
        
        //remove amount from database
        private void btRemove_Click(object sender, RoutedEventArgs e)
        {
            if (tbBarcodeUitgifte.Text != "" && tbProductUitgifte.Text != "" && iudAantalUitgifte.Text != "")
            {
                database.RemoveMedicijn(Convert.ToInt32(iudAantalUitgifte.Text), tbBarcodeUitgifte.Text);
                database.RemoveOverig(Convert.ToInt32(iudAantalUitgifte.Text), tbBarcodeUitgifte.Text);
                MessageBox.Show("Het aantal is aangepast");
                tbBarcodeUitgifte.Text = "";
            }
            else
            {
                MessageBox.Show("Niet alles is ingevuld");
            }
        }

        //add amount to database
        private void btAddBinnenkomst_Click(object sender, RoutedEventArgs e)
        {
            if (tbBarcodeBinnenkomst.Text != "" && tbProductBinnenkomst.Text != "" && iudAantalBinnenkomst.Text != "")
            {
                database.AddMedicijn(Convert.ToInt32(iudAantalBinnenkomst.Text), tbBarcodeBinnenkomst.Text);
                database.AddOverig(Convert.ToInt32(iudAantalBinnenkomst.Text), tbBarcodeBinnenkomst.Text);
                MessageBox.Show("Het aantal is aangepast");
                tbBarcodeBinnenkomst.Text = "";
                iudAantalBinnenkomst.Text = "0";
            }
            else
            {
                MessageBox.Show("Niet alles is ingevuld");
            }
        }

        //add amount to database
        private void btAddRetour_Click(object sender, RoutedEventArgs e)
        {
            if (tbBarcodeRetour.Text != "" && tbProductRetour.Text != "" && iudAantalRetour.Text != "")
            {
                database.AddMedicijn(Convert.ToInt32(iudAantalRetour.Text), tbBarcodeRetour.Text);
                database.AddOverig(Convert.ToInt32(iudAantalRetour.Text), tbBarcodeRetour.Text);
                MessageBox.Show("Het aantal is aangepast");
                tbBarcodeRetour.Text = "";
                iudAantalBinnenkomst.Text = "0";
            }
            else
            {
                MessageBox.Show("Niet alles is ingevuld");
            }
        }
    }
}
