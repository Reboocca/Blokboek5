﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace Vooraadbeheersysteem
{
    class DB
    {
        MySqlConnection conn = new MySqlConnection("Server=localhost;Database=voorraadbeheer;UID=root;pwd=;");

        // Login check
        public bool CheckLogin(string Login, string Wachtwoord)
        {
            conn.Open();
            MySqlCommand Check_login = new MySqlCommand("SELECT * FROM gebruikers WHERE Username = @Login and Password = @password", conn);
            Check_login.Parameters.AddWithValue("@Login", Login);
            Check_login.Parameters.AddWithValue("@password", Wachtwoord);
            MySqlDataReader reader = Check_login.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count += 1;
            }
            if (count == 1)
            {
                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }
        }

        // Checks rol for login
        public MainWindow.LoginData CheckRol(string Username)
        {
            var rolid = new MainWindow.LoginData();
            conn.Open();
            MySqlCommand comm = new MySqlCommand("SELECT * FROM gebruikers WHERE Username = @username", conn);
            comm.Parameters.AddWithValue("@username", Username);
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                rolid.RolID = reader.GetInt32("Rol");
            }
            conn.Close();
            return rolid;
        }

        // Checks if username is already in database
        public bool CheckUsername(string sUsername)
        {
            conn.Open();
            MySqlCommand check_Username = new MySqlCommand("SELECT * FROM gebruikers WHERE Username = @username");
            check_Username.Parameters.AddWithValue("@username", sUsername);
            MySqlDataReader reader = check_Username.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count += 1;
            }
            if (count >= 1)
            {
                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }
        }

        // Adds user in database
        public void InsertAccount(string Username, string Password, int rol)
        {
            conn.Open();
            MySqlCommand Insert = new MySqlCommand("INSERT INTO gebruikers (Rol, Username, Password) VALUES (@Rol, @Name, @Password)", conn);
            Insert.Parameters.AddWithValue("@Rol", rol);
            Insert.Parameters.AddWithValue("@Name", Username);
            Insert.Parameters.AddWithValue("@Password", Password);
            Insert.ExecuteNonQuery();
            conn.Close();
        }

        //Search barcode in database medicijnen
        public string SearchNameMedicijn(string barcode, string medicijn)
        {
            conn.Open();
            MySqlCommand SearchMedicijn = new MySqlCommand("SELECT Naam FROM medicijnen WHERE id = @id", conn);
            SearchMedicijn.Parameters.AddWithValue("@id", barcode);
            MySqlDataReader reader = SearchMedicijn.ExecuteReader();
            while (reader.Read())
            {
                medicijn = reader.GetString(0);
            }
            conn.Close();
            return medicijn;
        }

        //Search barcode in database overige
        public string SearchNameOverige(string barcode, string overige)
        {
            conn.Open();
            MySqlCommand SearchMedicijn = new MySqlCommand("SELECT Omschrijving FROM overige WHERE artnr = @artnr", conn);
            SearchMedicijn.Parameters.AddWithValue("@artnr", barcode);
            MySqlDataReader reader = SearchMedicijn.ExecuteReader();
            while (reader.Read())
            {
                overige = reader.GetString(0);
            }
            conn.Close();
            return overige;
        }

        //Maximum amount that can be taken from database medicijnen
        public int MaxMedicijn(string barcode, int MaxMedijnen)
        {
            conn.Open();
            MySqlCommand MaximumMedicijnen = new MySqlCommand("SELECT voorraad FROM medicijnen WHERE id = @id", conn);
            MaximumMedicijnen.Parameters.AddWithValue("@id", barcode);
            MySqlDataReader reader = MaximumMedicijnen.ExecuteReader();
            while (reader.Read())
            {
                MaxMedijnen = reader.GetInt32(0);
            }
            conn.Close();
            return MaxMedijnen;
        }

        //Maximum amount that can be taken from database overige
        public int MaxOverige(string barcode, int overigeMax)
        {
            conn.Open();
            MySqlCommand MaximumOverige = new MySqlCommand("SELECT lopendevoorraad FROM overige WHERE artnr = @artnr", conn);
            MaximumOverige.Parameters.AddWithValue("@artnr", barcode);
            MySqlDataReader reader = MaximumOverige.ExecuteReader();
            while (reader.Read())
            {
                overigeMax = reader.GetInt32(0);
            }
            conn.Close();
            return overigeMax;
        }

        //Remove amount from database medicijnen
        public void RemoveMedicijn(int amount, string barcode)
        {
            conn.Open();
            MySqlCommand Remove = new MySqlCommand("UPDATE medicijnen SET Voorraad = Voorraad - @amount WHERE id = @id", conn);
            Remove.Parameters.AddWithValue("@amount", amount);
            Remove.Parameters.AddWithValue("@id", barcode);
            Remove.ExecuteNonQuery();
            conn.Close();
        }

        //Add amount to database medicijnen
        public void AddMedicijn(int amount, string barcode)
        {
            conn.Open();
            MySqlCommand Add = new MySqlCommand("UPDATE medicijnen SET Voorraad = Voorraad + @amount WHERE id = @id", conn);
            Add.Parameters.AddWithValue("@amount", amount);
            Add.Parameters.AddWithValue("@id", barcode);
            Add.ExecuteNonQuery();
            conn.Close();
        }

        //Remove amount from database overige
        public void RemoveOverig(int amount, string barcode)
        {
            conn.Open();
            MySqlCommand Remove = new MySqlCommand("UPDATE overige SET lopendevoorraad = lopendevoorraad - @amount WHERE artnr = @artnr", conn);
            Remove.Parameters.AddWithValue("@amount", amount);
            Remove.Parameters.AddWithValue("@artnr", barcode);
            Remove.ExecuteNonQuery();
            conn.Close();
        }
         
        //Add amount to database overige
        public void AddOverig(int amount, string barcode)
        {
            conn.Open();
            MySqlCommand Add = new MySqlCommand("UPDATE overige SET lopendevoorraad = lopendevoorraad + @amount WHERE artnr = @artnr", conn);
            Add.Parameters.AddWithValue("@amount", amount);
            Add.Parameters.AddWithValue("@artnr", barcode);
            Add.ExecuteNonQuery();
            conn.Close();
        }
    }
}