﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Vooraadbeheersysteem
{
    class DB
    {
        MySqlConnection conn = new MySqlConnection("Server=localhost;Database=voorraadbeheer;UID=root;pwd=;");

        // Login check
        public bool CheckLogin(string Login, string Wachtwoord)
        {
            conn.Open();
            MySqlCommand Check_login = new MySqlCommand("select * from gebruikers where Username = @Login and Password = @password", conn);
            Check_login.Parameters.AddWithValue("@Login", Login);
            Check_login.Parameters.AddWithValue("@password", Wachtwoord);
            MySqlDataReader reader = Check_login.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count += 1;
            }
            if (count == 1)
            {
                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }
        }

        // Checks rol for login
        public MainWindow.LoginData CheckRol(string Username)
        {
            var rolid = new MainWindow.LoginData();
            conn.Open();
            MySqlCommand comm = conn.CreateCommand();
            comm.CommandText = "select * from `gebruikers` where `Username` = @username";
            comm.Parameters.AddWithValue("@username", Username);
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                rolid.RolID = reader.GetInt32("Rol");
            }
            conn.Close();
            return rolid;
        }

        // Checks if username is already in database
        public bool CheckUsername(string sUsername)
        {
            conn.Open();
            MySqlCommand check_Username = new MySqlCommand("select * from gebruikers where Username = @username", conn);
            check_Username.Parameters.AddWithValue("@username", sUsername);
            MySqlDataReader reader = check_Username.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count += 1;
            }
            if (count >= 1)
            {
                conn.Close();
                return true;
            }
            else
            {
                conn.Close();
                return false;
            }
        }

        // Adds user in database
        public void InsertAccount(string Username, string Password, int rol)
        {
            conn.Open();
            MySqlCommand Insert = new MySqlCommand("INSERT INTO gebruikers (Rol, Username, Password) VALUES (@Rol, @Name, @Password)", conn);
            Insert.Parameters.AddWithValue("@Rol", rol);
            Insert.Parameters.AddWithValue("@Name", Username);
            Insert.Parameters.AddWithValue("@Password", Password);
            Insert.ExecuteNonQuery();
            conn.Close();
        }
    }
}
