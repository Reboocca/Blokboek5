﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for Magazijn.xaml
    /// </summary>
    public partial class Magazijn : Window
    {
        DB database = new DB();
        bool isChar = true;

        public Magazijn()
        {
            InitializeComponent();
        }

        //auto product bij barcode zoeken
        private void tbBarcodeMedicijnen_TextChanged(object sender, TextChangedEventArgs e)
        {
            tbProductUitgifte.Text = String.Empty;
            tbProductBinnenkomst.Text = String.Empty;
            tbProductRetour.Text = String.Empty;

            //uitgifte
            foreach (char c in tbBarcodeUitgifte.Text)
            {
                if (!char.IsNumber(c))
                {
                    isChar = false;
                }
                if (isChar)
                {
                    if (tbBarcodeUitgifte.Text != String.Empty)
                    {
                        tbProductUitgifte.Text = database.SearchNameMedicijn(tbBarcodeUitgifte.Text, tbProductUitgifte.Text);
                        tbProductUitgifte.Text = database.SearchNameOverige(tbBarcodeUitgifte.Text, tbProductUitgifte.Text);
                        iudAantalUitgifte.Maximum = database.MaxMedicijn(tbBarcodeUitgifte.Text, Convert.ToInt32(iudAantalUitgifte.Maximum));
                        iudAantalUitgifte.Maximum = database.MaxOverige(tbBarcodeUitgifte.Text, Convert.ToInt32(iudAantalUitgifte.Maximum));
                    }
                }
                else
                {
                    tbBarcodeUitgifte.Text = String.Empty;
                    tbProductUitgifte.Text = String.Empty;
                    iudAantalUitgifte.Text = "0";
                    iudAantalUitgifte.Maximum = 0;
                    MessageBox.Show("Voer a.u.b. alleen cijfers in.");
                    isChar = true;
                }
            }

            //binnenkomst
            foreach (char c in tbBarcodeBinnenkomst.Text)
            {
                if (!char.IsNumber(c))
                {
                    isChar = false;
                }
                if (isChar)
                {
                    if (tbBarcodeBinnenkomst.Text != String.Empty)
                    {
                        tbProductBinnenkomst.Text = database.SearchNameMedicijn(tbBarcodeBinnenkomst.Text, tbProductBinnenkomst.Text);
                        tbProductBinnenkomst.Text = database.SearchNameOverige(tbBarcodeBinnenkomst.Text, tbProductBinnenkomst.Text);
                    }
                }
                else
                {
                    tbBarcodeBinnenkomst.Text = String.Empty;
                    tbProductBinnenkomst.Text = String.Empty;
                    iudAantalBinnenkomst.Text = "0";
                    iudAantalBinnenkomst.Maximum = 0;
                    MessageBox.Show("Voer a.u.b. alleen cijfers in.");
                    isChar = true;
                }
            }

            //retour
            foreach (char c in tbBarcodeRetour.Text)
            {
                if (!char.IsNumber(c))
                {
                    isChar = false;
                }
                if (isChar)
                {
                    if (tbBarcodeRetour.Text != String.Empty)
                    {
                        tbProductRetour.Text = database.SearchNameMedicijn(tbBarcodeRetour.Text, tbProductRetour.Text);
                        tbProductRetour.Text = database.SearchNameOverige(tbBarcodeRetour.Text, tbProductRetour.Text);
                    }
                }
                else
                {
                    tbBarcodeRetour.Text = String.Empty;
                    tbProductRetour.Text = String.Empty;
                    iudAantalRetour.Text = "0";
                    iudAantalRetour.Maximum = 0;
                    MessageBox.Show("Voer a.u.b. alleen cijfers in.");
                    isChar = true;
                }
            }
        }
        
        //remove amount from database
        private void btRemove_Click(object sender, RoutedEventArgs e)
        {
            if (tbBarcodeUitgifte.Text != String.Empty && tbProductUitgifte.Text != String.Empty && iudAantalUitgifte.Text != String.Empty)
            {
                database.RemoveMedicijn(Convert.ToInt32(iudAantalUitgifte.Text), tbBarcodeUitgifte.Text);
                database.RemoveOverig(Convert.ToInt32(iudAantalUitgifte.Text), tbBarcodeUitgifte.Text);
                MessageBox.Show("Het aantal is aangepast");
                tbBarcodeUitgifte.Text = String.Empty;
                iudAantalUitgifte.Text = "0";
                iudAantalUitgifte.Maximum = 0;
            }
            else
            {
                MessageBox.Show("Niet alles is ingevuld");
            }
        }

        //add amount to database
        private void btAddBinnenkomst_Click(object sender, RoutedEventArgs e)
        {
            if (tbBarcodeBinnenkomst.Text != String.Empty && tbProductBinnenkomst.Text != String.Empty && iudAantalBinnenkomst.Text != String.Empty)
            {
                database.AddMedicijn(Convert.ToInt32(iudAantalBinnenkomst.Text), tbBarcodeBinnenkomst.Text);
                database.AddOverig(Convert.ToInt32(iudAantalBinnenkomst.Text), tbBarcodeBinnenkomst.Text);
                MessageBox.Show("Het aantal is aangepast");
                tbBarcodeBinnenkomst.Text = String.Empty;
                iudAantalBinnenkomst.Text = "0";
                iudAantalBinnenkomst.Maximum = 0;
            }
            else
            {
                MessageBox.Show("Niet alles is ingevuld");
            }
        }

        //add amount to database
        private void btAddRetour_Click(object sender, RoutedEventArgs e)
        {
            if (tbBarcodeRetour.Text != String.Empty && tbProductRetour.Text != String.Empty && iudAantalRetour.Text != String.Empty)
            {
                database.AddMedicijn(Convert.ToInt32(iudAantalRetour.Text), tbBarcodeRetour.Text);
                database.AddOverig(Convert.ToInt32(iudAantalRetour.Text), tbBarcodeRetour.Text);
                MessageBox.Show("Het aantal is aangepast");
                tbBarcodeRetour.Text = String.Empty;
                iudAantalRetour.Text = "0";
                iudAantalRetour.Maximum = 0;
            }
            else
            {
                MessageBox.Show("Niet alles is ingevuld");
            }
        }

        private void resetvalues(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source is TabControl)
            {
                tbBarcodeUitgifte.Text = String.Empty;
                tbProductUitgifte.Text = String.Empty;
                iudAantalUitgifte.Maximum = 0;
                tbBarcodeBinnenkomst.Text = String.Empty;
                tbProductBinnenkomst.Text = String.Empty;
                iudAantalBinnenkomst.Maximum = 9999;
                tbBarcodeRetour.Text = String.Empty;
                tbProductRetour.Text = String.Empty;
                iudAantalRetour.Maximum = 9999;
                tbBarcodeUitgifte.Focus();
                tbBarcodeBinnenkomst.Focus();
                tbBarcodeRetour.Focus();
            }
        }

        private void Logout(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow login = new MainWindow();
            login.ShowDialog();
            this.Close();
        }
    }
}
