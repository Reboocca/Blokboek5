﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Xml.Serialization;
using System.IO;
using Xceed.Wpf.DataGrid;

namespace Vooraadbeheersysteem
{
    /// <summary>
    /// Interaction logic for Logistiek.xaml
    /// </summary>
    public partial class Logistiek : Window
    {
        MySqlConnection con = new MySqlConnection("Server=localhost;Database=voorraadbeheer;UID=root;pwd=;");
        DataTable dtBestel = new DataTable();
        DataTable dtXml = new DataTable();
        DataTable dtDateTomorrow = new DataTable();
        DataTable dtDateToday = new DataTable();
        DataSet dsXml = new DataSet();
        DataTable dtMed = new DataTable();
        DataTable dtOverige = new DataTable();
        DataSet dsMed = new DataSet();
        DataSet dsOverige = new DataSet();
        MySqlDataAdapter adapterMed;
        MySqlDataAdapter adapterOverige;

        public Logistiek()
        {
            InitializeComponent();
            GetOverzichtMed();
            GetOverzichtOverige();
            GetVoorstel();
            tbSearchMedicijn.Focus();
        }

        private void GetOverzichtMed()
        {
            con.Open();
            MySqlCommand GetMed = new MySqlCommand("SELECT id, Naam, GeregistreerdOfGeneriek, ReceptOfZelfzorg, BCGofEU, Homeopatisch, FNA, Toedieningsvorm, Bestelgrootte, Bestelniveau, Doelvoorraad, Schapcode, Verrekenprijs, Prijs, Voorraad FROM medicijnen", con);
            con.Close();

            adapterMed = new MySqlDataAdapter(GetMed);
            adapterMed.Fill(dtMed);

            dgVoorraadMed.ItemsSource = dtMed.DefaultView;
        }

        private void GetOverzichtOverige()
        {
            con.Open();
            MySqlCommand GetOver = new MySqlCommand("SELECT artnr, omschrijving, verstreenheid, crednr, serieletter, systeemdeelletter, `gewenste voorraad`, verpakkingsfactor, bestelniveau, wekenvoorraad, brutoprijs, schapcode, lopendevoorraad FROM overige", con);
            con.Close();

            adapterOverige = new MySqlDataAdapter(GetOver);
            adapterOverige.Fill(dtOverige);
            dsMed.AcceptChanges();
            dgVoorraadOverige.ItemsSource = dtOverige.DefaultView;
        }

        private void GetVoorstel()
        {
            con.Open();
            MySqlCommand GetMed = new MySqlCommand("SELECT id AS nr, Naam AS naam, Doelvoorraad - Voorraad AS aantal FROM medicijnen WHERE Voorraad <= Bestelniveau", con);
            MySqlCommand GetOverig = new MySqlCommand("SELECT artnr AS nr, omschrijving AS Naam, `gewenste voorraad` - lopendevoorraad AS aantal FROM overige WHERE lopendevoorraad <= bestelniveau", con);
            con.Close();

            MySqlDataAdapter adapter1 = new MySqlDataAdapter(GetMed);
            adapter1.Fill(dtBestel);
            MySqlDataAdapter adapter2 = new MySqlDataAdapter(GetOverig);
            adapter2.Fill(dtBestel);
            dgvoorstel.ItemsSource = dtBestel.DefaultView;
        }

        private void Refresh(object sender, RoutedEventArgs e)
        {
            dgVoorraadMed.ItemsSource = String.Empty;
            dgVoorraadOverige.ItemsSource = String.Empty;
            dgvoorstel.ItemsSource = String.Empty;
            dtMed.Clear();
            dtOverige.Clear();
            dtBestel.Clear();
            MessageBox.Show("De gegevens worden opnieuw geladen");
            GetOverzichtMed();
            GetOverzichtOverige();
            GetVoorstel();
        }

        private void xmlSaveVoorstel(object sender, RoutedEventArgs e)
        {
            var tomorrow = DateTime.Today.AddDays(1).ToShortDateString();
            var today = DateTime.Today.ToShortDateString();
            dtDateToday.Columns.Add("DatumVandaag");
            dtDateToday.Rows.Add(today);
            dtDateToday.TableName = "datumref";
            dtDateTomorrow.Columns.Add("DatumMorgen");
            dtDateTomorrow.Rows.Add(tomorrow);
            dtDateTomorrow.TableName = "leverdatum";
            DateTime.Now.ToShortDateString();
            dtXml = ((DataView)dgvoorstel.ItemsSource).ToTable();
            dtXml.TableName = "artikel";
            dsXml.DataSetName = "bestelling";
            dsXml.Tables.Add(dtDateToday);
            dsXml.Tables.Add(dtDateTomorrow);
            dsXml.Tables.Add(dtXml);
            dsXml.WriteXml(@"C:\Users\Beau\Desktop\Order.xml");
            MessageBox.Show("De spullen die moeten worden gekocht zijn opgeslagen in een bestand.");
        }

        private void Logout(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow login = new MainWindow();
            login.ShowDialog();
            this.Close();
        }

        private void SearchMed(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                con.Open();
                MySqlCommand SearchMed = new MySqlCommand("SELECT id, Naam, GeregistreerdOfGeneriek, ReceptOfZelfzorg, BCGofEU, Homeopatisch, FNA, Toedieningsvorm, Bestelgrootte, Bestelniveau, Doelvoorraad, Schapcode, Verrekenprijs, Prijs, Voorraad FROM medicijnen where Naam like '" + tbSearchMedicijn.Text + "%'", con);
                DataTable dtSearchMed = new DataTable();
                MySqlDataAdapter adapterSearchMed = new MySqlDataAdapter(SearchMed);
                adapterSearchMed.Fill(dtSearchMed);
                dgVoorraadMed.ItemsSource = String.Empty;
                dgVoorraadMed.ItemsSource = dtSearchMed.DefaultView;
                con.Close();
            } 
        }

        private void SearchOverige(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                con.Open();
                MySqlCommand SearchOverige = new MySqlCommand("SELECT artnr, omschrijving, verstreenheid, besteleenheid, crednr, serieletter, systeemdeelletter, `gewenste voorraad`, verpakkingsfactor, bestelniveau, wekenvoorraad, brutoprijs, schapcode, lopendevoorraad FROM overige where omschrijving like '" + tbSearchOverige.Text + "%'", con);
                DataTable dtSearchOverige = new DataTable();
                MySqlDataAdapter adapterSearchOverige = new MySqlDataAdapter(SearchOverige);
                adapterSearchOverige.Fill(dtSearchOverige);
                dgVoorraadOverige.ItemsSource = String.Empty;
                dgVoorraadOverige.ItemsSource = dtSearchOverige.DefaultView;
                con.Close();
            }
        }

        private void resetvalues(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source is TabControl)
            {
                if (tbSearchMedicijn.Text != String.Empty)
                {
                    tbSearchMedicijn.Text = String.Empty;
                    GetOverzichtMed();
                }
                if (tbSearchOverige.Text != String.Empty)
                {
                    tbSearchOverige.Text = String.Empty;
                    GetOverzichtOverige();
                }
                tbSearchMedicijn.Focus();
                tbSearchOverige.Focus();
            }
        }

        private void btSaveMedicijn_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = ((DataView)dgVoorraadMed.ItemsSource).ToTable();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO medicijnen (id, Naam , GeregistreerdOfGeneriek, ReceptOfZelfzorg, BCGofEU, Homeopatisch, FNA, Toedieningsvorm, Bestelgrootte, Bestelniveau, Doelvoorraad, Schapcode, Verrekenprijs, Prijs, Voorraad) VALUES (@val1, @val2, @val3, @val4, @val5, @val6, @val7, @val8, @val9, @val10, @val11, @val12, @val13, @val14, @val15) ON DUPLICATE KEY UPDATE Naam=@val2, GeregistreerdOfGeneriek=@val3, ReceptOfZelfzorg=@val4, BCGofEU=@val5, Homeopatisch=@val6, FNA=@val7, Toedieningsvorm=@val8, Bestelgrootte=@val9, Bestelniveau=@val10, Doelvoorraad=@val11, Schapcode=@val12, Verrekenprijs=@val13, Prijs=@val14, Voorraad=@val15", con))
                {
                    cmd.Parameters.AddWithValue("@val1", dt.Rows[i][0]);
                    cmd.Parameters.AddWithValue("@val2", dt.Rows[i][1]);
                    cmd.Parameters.AddWithValue("@val3", dt.Rows[i][2]);
                    cmd.Parameters.AddWithValue("@val4", dt.Rows[i][3]);
                    cmd.Parameters.AddWithValue("@val5", dt.Rows[i][4]);
                    cmd.Parameters.AddWithValue("@val6", dt.Rows[i][5]);
                    cmd.Parameters.AddWithValue("@val7", dt.Rows[i][6]);
                    cmd.Parameters.AddWithValue("@val8", dt.Rows[i][7]);
                    cmd.Parameters.AddWithValue("@val9", dt.Rows[i][8]);
                    cmd.Parameters.AddWithValue("@val10", dt.Rows[i][9]);
                    cmd.Parameters.AddWithValue("@val11", dt.Rows[i][10]);
                    cmd.Parameters.AddWithValue("@val12", dt.Rows[i][11]);
                    cmd.Parameters.AddWithValue("@val13", dt.Rows[i][12]);
                    cmd.Parameters.AddWithValue("@val14", dt.Rows[i][13]);
                    cmd.Parameters.AddWithValue("@val15", dt.Rows[i][14]);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }

            tbSearchMedicijn.Text = String.Empty;
            dgVoorraadMed.ItemsSource = String.Empty;
            MessageBox.Show("De informatie is aangepast en/of toegevoegd");
            GetOverzichtMed();
        }

        private void OpslaanOverige_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = ((DataView)dgVoorraadOverige.ItemsSource).ToTable();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO overige (artnr, omschrijving , verstreenheid, besteleenheid, crednr, serieletter, systeemdeelletter, `gewenste voorraad`, verpakkingsfactor, bestelniveau, wekenvoorraad, brutoprijs, schapcode, lopendevoorraad) VALUES (@val1, @val2, @val3, @val4, @val5, @val6, @val7, @val8, @val9, @val10, @val11, @val12, @val13, @val14) ON DUPLICATE KEY UPDATE omschrijving=@val2, verstreenheid=@val3, besteleenheid=@val4, crednr=@val5, serieletter=@val6, systeemdeelletter=@val7, `gewenste voorraad`=@val8, verpakkingsfactor=@val9, bestelniveau=@val10, wekenvoorraad=@val11, brutoprijs=@val12, schapcode=@val13, lopendevoorraad=@val14", con))
                {
                    cmd.Parameters.AddWithValue("@val1", dt.Rows[i][0]);
                    cmd.Parameters.AddWithValue("@val2", dt.Rows[i][1]);
                    cmd.Parameters.AddWithValue("@val3", dt.Rows[i][2]);
                    cmd.Parameters.AddWithValue("@val4", dt.Rows[i][3]);
                    cmd.Parameters.AddWithValue("@val5", dt.Rows[i][4]);
                    cmd.Parameters.AddWithValue("@val6", dt.Rows[i][5]);
                    cmd.Parameters.AddWithValue("@val7", dt.Rows[i][6]);
                    cmd.Parameters.AddWithValue("@val8", dt.Rows[i][7]);
                    cmd.Parameters.AddWithValue("@val9", dt.Rows[i][8]);
                    cmd.Parameters.AddWithValue("@val10", dt.Rows[i][9]);
                    cmd.Parameters.AddWithValue("@val11", dt.Rows[i][10]);
                    cmd.Parameters.AddWithValue("@val12", dt.Rows[i][11]);
                    cmd.Parameters.AddWithValue("@val13", dt.Rows[i][12]);
                    cmd.Parameters.AddWithValue("@val14", dt.Rows[i][13]);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }

            tbSearchOverige.Text = String.Empty;
            dgVoorraadOverige.ItemsSource = String.Empty;
            MessageBox.Show("De informatie is aangepast en/of toegevoegd");
            GetOverzichtOverige();
        }

        private void DeleteMed(object sender, RoutedEventArgs e)
        {
            int i = dgVoorraadMed.SelectedIndex;
            DataRowView v = (DataRowView)dgVoorraadMed.Items[i];
            string s = v[0].ToString();

            MySqlCommand cmd = new MySqlCommand("DELETE FROM medicijnen WHERE id = @id", con);
            cmd.Parameters.AddWithValue("@id", s);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            tbSearchMedicijn.Text = String.Empty;
            dgVoorraadMed.ItemsSource = String.Empty;
            MessageBox.Show("De geselecteerde informatie is verwijderd");
            GetOverzichtMed();
        }

        private void DeleteOverige(object sender, RoutedEventArgs e)
        {
            int i = dgVoorraadOverige.SelectedIndex;
            DataRowView v = (DataRowView)dgVoorraadOverige.Items[i];
            string s = v[0].ToString();

            MySqlCommand cmd = new MySqlCommand("DELETE FROM overige WHERE artnr = @artnr", con);
            cmd.Parameters.AddWithValue("@artnr", s);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            tbSearchOverige.Text = String.Empty;
            dgVoorraadOverige.ItemsSource = String.Empty;
            MessageBox.Show("De geselecteerde informatie is verwijderd");
            GetOverzichtOverige();
        }
    }
}
